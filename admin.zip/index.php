<?php
  header("location: web");
?>