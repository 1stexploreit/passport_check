// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable();
});

// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTables').DataTable();
});
